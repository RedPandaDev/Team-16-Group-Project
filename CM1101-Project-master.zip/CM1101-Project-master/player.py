#This has the player information and stats
from map import rooms
current_room = rooms["Room 2"]
player_stats = {"strength": 5,"defence": 5, "health": 100, "weapon":10, "credits": 50}
inventory = []

item_1 = {
    "name": " Strength Upgrade",
    "id": "1",
    "description": "A +5 to strength upgrade",
    "cost": 25
    }
item_2 = {
    "name": " Defence Upgrade",
    "id": "2",
    "description": "A +5 to defence upgrade",
    "cost": 25
    }
item_3 = {
    "name": " Health Upgrade",
    "id": "3",
    "description": " +25 to health",
    "cost": 20
    }
item_4 = {
    "name": " All Stats Upgrade",
    "id": "4",
    "description": "All stats upgrade BEST VALUE!",
    "cost": 60
    }
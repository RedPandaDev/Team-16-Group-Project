3 """The gold glint in the corner of your eye instantly
catches your attention as you enter,
no lock, yet untouched,
precious resources may lie inside!"""

4 """ Silence in here, 
all that remains are the screams of those once here,
just as the blackness of 
space... nothing is here... nothing."""

5 """ BOOM, BOOM, BOOM, 
you here the thud of terror aproach you!
it has awoken, it is fresh, 
unfortunately it is HUNGRY! """

6 """ What approaches you is daunting,
its objective is cruel.
if base could see you now,
they would think your a fool."""

7 """ What happened here is unspeakable,
 limbs hanging from the ovehead wires.
 drip... drip... drip."""

8 """ You enter only to find a room untouched,
this was once the dining room,
where colleagues would come together to discuss reaserch and to enjoy conversation.
Food still on the plate, water still in the cups.
There had been an evacuation here."""

9 """ A light blinks in the corner, you go over to it, 
only to find it open.
You look inside... a small fortune awaits you!
Take it quickly, at least now you will die a rich man."""

10 """ The object in the corner is open,
inside there are weapons of dubious value.
Enjoy.""" 
